import warnings
warnings.filterwarnings('ignore', '.*support Decimal objects natively.*')
